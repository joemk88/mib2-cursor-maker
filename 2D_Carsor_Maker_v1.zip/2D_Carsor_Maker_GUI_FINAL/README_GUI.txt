Audi/VW MMI 2D Carsor Maker

How to use:
  1) Double-click carsor_gui.py (or run: python carsor_gui.py)
  2) Select your 256×256 transparent PNG
  3) Choose output location
  4) Click Build
  5) Rename the generated file to objects.cff before copying it to the vehicle
  6) Copy objects.cff to MMI using SSH. In my case /mnt/app/navigation/resources/app/au/aus/models/ but will depend on your vehicle.


