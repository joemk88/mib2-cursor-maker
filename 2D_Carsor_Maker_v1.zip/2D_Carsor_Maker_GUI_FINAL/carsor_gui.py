#!/usr/bin/env python3
"""
Carsor 2D Maker (GUI)
- No Pillow dependency.
- Expects the user to provide a 256x256 PNG with transparency.
- Rebuilds carsorshadow.sfc, then repacks objects.cff.

Folder layout (expected beside this script):
  rebuild-sfc.py
  compress-cff.py
  original_objects.cff
  original_carsorshadow.sfc
  carsorshadow/   (contains file_0.. bins etc; we'll overwrite file_5.png)
  CUSTOM/         (contains carsor.sfc (invisible), carsorshadow.sfc output target, crosshair.sfc, crosshairshadow.sfc)
"""

import os, sys, struct, subprocess, time
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

APP_TITLE = "Audi MMI 2D Carsor Maker"

def is_png_256_with_alpha(p: Path):
    b = p.read_bytes()
    if len(b) < 8 or b[:8] != b"\x89PNG\r\n\x1a\n":
        return False, "Not a PNG file (missing PNG signature)."
    # Walk chunks
    off = 8
    w = h = None
    color_type = None
    has_trns = False
    while off + 8 <= len(b):
        if off + 8 > len(b): break
        length = struct.unpack(">I", b[off:off+4])[0]
        ctype = b[off+4:off+8]
        data_off = off + 8
        data_end = data_off + length
        crc_end = data_end + 4
        if crc_end > len(b):
            break
        if ctype == b'IHDR':
            if length != 13:
                return False, "Invalid IHDR length."
            w = struct.unpack(">I", b[data_off:data_off+4])[0]
            h = struct.unpack(">I", b[data_off+4:data_off+8])[0]
            bit_depth = b[data_off+8]
            color_type = b[data_off+9]
            # We don't enforce bit_depth beyond sanity; many tools use 8.
        elif ctype == b'tRNS':
            has_trns = True
        elif ctype == b'IEND':
            break
        off = crc_end

    if w is None or h is None:
        return False, "PNG missing IHDR."
    if w != 256 or h != 256:
        return False, f"PNG must be 256x256. Got {w}x{h}."
    # color_type: 4 (grayscale+alpha) or 6 (RGBA) are explicit alpha
    # color_type 3 (indexed) can have alpha via tRNS
    if color_type in (4, 6):
        return True, "OK"
    if color_type == 3 and has_trns:
        return True, "OK (indexed with tRNS transparency)"
    return False, "PNG must include transparency (alpha channel). Export as RGBA (preferred)."

def run_py(script: Path, args):
    # Use current python to run sibling scripts
    cmd = [sys.executable, str(script)] + [str(a) for a in args]
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("720x420")

        self.base_dir = Path(__file__).resolve().parent / 'app'
        self.png_path = tk.StringVar(value="")
        self.out_path = tk.StringVar(value=str(Path(__file__).resolve().parent / "objects_custom.cff"))

        # UI
        frm = tk.Frame(self, padx=12, pady=12)
        frm.pack(fill="both", expand=True)

        tk.Label(frm, text="1) Select your cursor PNG (256×256, transparent):").pack(anchor="w")
        row1 = tk.Frame(frm)
        row1.pack(fill="x", pady=(6, 14))
        tk.Entry(row1, textvariable=self.png_path).pack(side="left", fill="x", expand=True)
        tk.Button(row1, text="Browse…", command=self.pick_png).pack(side="left", padx=(8,0))

        tk.Label(frm, text="2) Output objects.cff location:").pack(anchor="w")
        row2 = tk.Frame(frm)
        row2.pack(fill="x", pady=(6, 14))
        tk.Entry(row2, textvariable=self.out_path).pack(side="left", fill="x", expand=True)
        tk.Button(row2, text="Save as…", command=self.pick_out).pack(side="left", padx=(8,0))

        tk.Label(frm, text="3) Build").pack(anchor="w")
        tk.Button(frm, text="Build objects.cff", height=2, command=self.build).pack(anchor="w", pady=(6, 10))

        tk.Label(frm, text="Log:").pack(anchor="w")
        self.log = tk.Text(frm, height=10, wrap="word")
        self.log.pack(fill="both", expand=True)
        self.log.configure(state="disabled")

        self.append_log("Ready.\n")

    def append_log(self, s: str):
        self.log.configure(state="normal")
        self.log.insert("end", s)
        self.log.see("end")
        self.log.configure(state="disabled")
        self.update_idletasks()

    def pick_png(self):
        p = filedialog.askopenfilename(title="Select 256x256 transparent PNG", filetypes=[("PNG files","*.png"), ("All files","*.*")])
        if p:
            self.png_path.set(p)

    def pick_out(self):
        p = filedialog.asksaveasfilename(title="Save output objects.cff", defaultextension=".cff", filetypes=[("CFF files","*.cff"), ("All files","*.*")])
        if p:
            self.out_path.set(p)

    def build(self):
        try:
            png = Path(self.png_path.get()).expanduser()
            out = Path(self.out_path.get()).expanduser()
            if not png.exists():
                messagebox.showerror("Missing PNG", "Please select a PNG file.")
                return

            ok, msg = is_png_256_with_alpha(png)
            if not ok:
                messagebox.showerror("PNG check failed", msg)
                return

            # Expected paths
            rebuild_sfc = self.base_dir / "rebuild-sfc.py"
            compress_cff = self.base_dir / "compress-cff.py"
            orig_shadow = self.base_dir / "original_carsorshadow.sfc"
            orig_objects = self.base_dir / "original_objects.cff"
            carsorshadow_dir = self.base_dir / "carsorshadow"
            custom_dir = self.base_dir / "CUSTOM"

            missing = [p for p in [rebuild_sfc, compress_cff, orig_shadow, orig_objects, carsorshadow_dir, custom_dir] if not p.exists()]
            if missing:
                messagebox.showerror("Missing files", "These required files/folders are missing:\n" + "\n".join(str(m) for m in missing))
                return

            # Step 2: write png into carsorshadow as file_5.png (case-insensitive)
            target_png = carsorshadow_dir / "file_5.png"
            target_png.write_bytes(png.read_bytes())
            self.append_log(f"✓ Copied PNG to {target_png}\n")

            # Step 3: rebuild carsorshadow.sfc into CUSTOM/carsorshadow.sfc
            out_shadow = custom_dir / "carsorshadow.sfc"
            self.append_log("… Rebuilding carsorshadow.sfc\n")
            rc, so, se = run_py(rebuild_sfc, [orig_shadow, carsorshadow_dir, out_shadow])
            self.append_log(so)
            if rc != 0:
                self.append_log(se)
                messagebox.showerror("rebuild-sfc failed", "rebuild-sfc.py failed.\nSee log for details.")
                return
            self.append_log(f"✓ Built {out_shadow}\n")

            # Step 4: compress cff
            self.append_log("… Packing objects.cff\n")
            tmp_out = out
            rc, so, se = run_py(compress_cff, [orig_objects, tmp_out, custom_dir])
            self.append_log(so)
            if rc != 0:
                self.append_log(se)
                messagebox.showerror("compress-cff failed", "compress-cff.py failed.\nSee log for details.")
                return
            self.append_log(f"✓ Wrote {tmp_out}\n")
            messagebox.showinfo("Done", f"Built:\n{tmp_out}")

        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.append_log(f"\nERROR: {e}\n")

if __name__ == "__main__":
    App().mainloop()
