# build-sfc.py
# Rebuilds an SFC container produced by extract-sfc.py
#
# Usage:
#   python build-sfc.py <template.sfc> <input_folder> <output.sfc> [--same-size]
#
# input_folder must contain:
#   file_0.png/bin, file_1.png/bin, ... file_{N-1}.png/bin
#
# --same-size (optional):
#   Pads/truncates output to match template size (only safe if the MMI expects fixed size)

import os
import re
import sys
import struct
from pathlib import Path

def read_u32_le(buf: bytes, off: int) -> int:
    return struct.unpack_from("<I", buf, off)[0]

def pack_u32_le(x: int) -> bytes:
    return struct.pack("<I", x)

def align(x: int, a: int) -> int:
    return (x + (a - 1)) & ~(a - 1)

def find_file_for_index(folder: Path, idx: int) -> Path:
    # Accept any extension: file_0.png, file_0.bin, file_0.dat, etc.
    pat = re.compile(rf"^file_{idx}\.(.+)$", re.IGNORECASE)
    matches = []
    for p in folder.iterdir():
        if p.is_file() and pat.match(p.name):
            matches.append(p)
    if len(matches) == 0:
        raise FileNotFoundError(f"Missing file for index {idx}: expected file_{idx}.* in {folder}")
    if len(matches) > 1:
        # Prefer .png or .bin if multiple
        matches.sort(key=lambda p: (p.suffix.lower() not in [".png", ".bin"], p.name.lower()))
    return matches[0]

def main():
    if len(sys.argv) < 4:
        print("usage: python build-sfc.py <template.sfc> <input_folder> <output.sfc> [--same-size]")
        sys.exit(1)

    template_path = Path(sys.argv[1])
    in_dir = Path(sys.argv[2])
    out_path = Path(sys.argv[3])
    same_size = "--same-size" in sys.argv[4:]

    if not template_path.exists():
        sys.exit(f"Template not found: {template_path}")
    if not in_dir.exists() or not in_dir.is_dir():
        sys.exit(f"Input folder not found: {in_dir}")

    tpl = template_path.read_bytes()

    # Format per extract-sfc.py:
    # offset 0x10: num_files (u32)
    if len(tpl) < 0x14:
        sys.exit("Template too small to be a valid SFC container.")

    num_files = read_u32_le(tpl, 0x10)
    toc_start = 0x14
    toc_entry_size = 16
    toc_size = num_files * toc_entry_size
    header_size = toc_start + toc_size

    if len(tpl) < header_size:
        sys.exit(f"Template too small for TOC: num_files={num_files}, header_size={header_size}")

    # Read original TOC entries, preserve id + unknown1
    entries = []
    off = toc_start
    for i in range(num_files):
        file_id = read_u32_le(tpl, off + 0)
        unknown1 = read_u32_le(tpl, off + 4)
        start_off = read_u32_le(tpl, off + 8)
        size = read_u32_le(tpl, off + 12)
        entries.append({
            "i": i,
            "id": file_id,
            "unknown1": unknown1,
            "start_off": start_off,
            "size": size,
        })
        off += toc_entry_size

    # Load replacement blobs in order
    blobs = []
    for i in range(num_files):
        p = find_file_for_index(in_dir, i)
        blobs.append(p.read_bytes())

    # Rebuild payload starting right after header, 4-byte aligned
    out = bytearray()
    out.extend(tpl[:header_size])  # placeholder TOC will be overwritten below

    cur = header_size
    new_offsets = []
    new_sizes = []
    payload = bytearray()

    for i, blob in enumerate(blobs):
        cur_aligned = align(cur, 4)
        # pad payload to alignment
        if cur_aligned > cur:
            payload.extend(b"\x00" * (cur_aligned - cur))
            cur = cur_aligned
        new_offsets.append(cur)
        new_sizes.append(len(blob))
        payload.extend(blob)
        cur += len(blob)

    # Write updated TOC back into out[0:header_size]
    # Keep the original ids/unknown1; only update offset/size
    toc_bytes = bytearray()
    for i, e in enumerate(entries):
        toc_bytes += pack_u32_le(e["id"])
        toc_bytes += pack_u32_le(e["unknown1"])
        toc_bytes += pack_u32_le(new_offsets[i])
        toc_bytes += pack_u32_le(new_sizes[i])

    # Patch TOC region
    out[toc_start:toc_start + toc_size] = toc_bytes

    # Append payload
    out.extend(payload)

    # Optionally force same size as template (ONLY if you know MMI expects fixed size)
    if same_size:
        if len(out) < len(tpl):
            out.extend(b"\x00" * (len(tpl) - len(out)))
        elif len(out) > len(tpl):
            # truncation is dangerous; but provided as an option because you asked about strict offsets/TOC behavior
            out = out[:len(tpl)]

    out_path.write_bytes(out)

    print(f"Template: {template_path} ({len(tpl)} bytes)")
    print(f"Output:   {out_path} ({len(out)} bytes)")
    print(f"Files:    {num_files}")
    for i in range(num_files):
        print(f"  file_{i}: offset=0x{new_offsets[i]:X} size={new_sizes[i]}")

if __name__ == "__main__":
    main()