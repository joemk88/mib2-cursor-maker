import os
import sys
import struct

def read_u32(data, off):
    return struct.unpack_from("<I", data, off)[0]

def parse_cff(data):
    # Header fields used by the extractor
    toc_size = read_u32(data, 24)
    num_files = read_u32(data, 28)

    # TOC2 start matches extractor logic
    # After reading num_files (offset=28), extractor does:
    # offset = offset + 4 + (toc_size*4) + (num_files*20)
    toc2_start = 32 + (toc_size * 4) + (num_files * 20)

    entries = []
    off = toc2_start

    for _ in range(num_files):
        path_len, unknown1, unknown2 = struct.unpack_from("<III", data, off)
        off += 12

        extra = None
        # extractor: if unknown1 != 8388608, it effectively skips 4 more bytes
        if unknown1 != 8388608:
            extra = read_u32(data, off)
            off += 4

        file_size = read_u32(data, off); off += 4
        file_offset = read_u32(data, off); off += 4
        path_bytes = struct.unpack_from(f"<{path_len}s", data, off)[0]
        off += path_len

        entries.append({
            "path_len": path_len,
            "unknown1": unknown1,
            "unknown2": unknown2,
            "extra": extra,              # present only when unknown1 != 8388608
            "file_size": file_size,
            "file_offset": file_offset,
            "path_bytes": path_bytes,
        })

    data_start = min(e["file_offset"] for e in entries) if entries else len(data)
    return {
        "toc_size": toc_size,
        "num_files": num_files,
        "toc2_start": toc2_start,
        "toc2_end": off,
        "data_start": data_start,
        "entries": entries
    }

def build_toc2(entries, new_offsets_and_sizes):
    """
    new_offsets_and_sizes: dict[path_bytes] -> (new_offset, new_size)
    """
    out = bytearray()
    for e in entries:
        path = e["path_bytes"]
        path_len = e["path_len"]
        unknown1 = e["unknown1"]
        unknown2 = e["unknown2"]
        extra = e["extra"]

        if path not in new_offsets_and_sizes:
            raise RuntimeError(f"Missing replacement file for TOC path: {path!r}")

        new_off, new_size = new_offsets_and_sizes[path]

        out += struct.pack("<III", path_len, unknown1, unknown2)
        if unknown1 != 8388608:
            # preserve the extra field value exactly
            out += struct.pack("<I", extra if extra is not None else 0)

        out += struct.pack("<I", new_size)
        out += struct.pack("<I", new_off)
        out += path
    return bytes(out)

def main():
    if len(sys.argv) != 4:
        print("usage: compress-cff_v2.py <original.cff> <output.cff> <folder_with_replacements>")
        sys.exit(1)

    in_cff = sys.argv[1]
    out_cff = sys.argv[2]
    src_dir = sys.argv[3]

    data = open(in_cff, "rb").read()
    info = parse_cff(data)

    entries = info["entries"]
    toc2_start = info["toc2_start"]
    data_start = info["data_start"]

    print(f"toc_size: {info['toc_size']}")
    print(f"num_files: {info['num_files']}")
    print(f"toc2_start: {toc2_start}")
    print(f"data_start: {data_start}")
    print("paths in TOC2:")
    for e in entries:
        print(" -", e["path_bytes"].decode("utf-8", errors="replace"))

    # Read replacement files (must match TOC2 paths by filename)
    # This assumes the TOC2 paths are just filenames or relative paths.
    # We normalize leading slashes so Windows doesn't treat them as absolute.
    replacements = {}
    for e in entries:
        rel = e["path_bytes"].decode("utf-8")
        rel_norm = rel.lstrip("/\\")
        full = os.path.join(src_dir, rel_norm)

        if not os.path.exists(full):
            raise FileNotFoundError(f"Replacement missing: expected {full}")

        blob = open(full, "rb").read()
        replacements[e["path_bytes"]] = blob

    # Pack files sequentially starting at the ORIGINAL data_start
    cur = data_start
    new_offsets_and_sizes = {}
    new_data = bytearray()

    for e in entries:
        path = e["path_bytes"]
        blob = replacements[path]
        new_offsets_and_sizes[path] = (cur, len(blob))
        new_data += blob
        cur += len(blob)

    # Rebuild TOC2
    new_toc2 = build_toc2(entries, new_offsets_and_sizes)

    # Important: keep the region between toc2_start and data_start the same size,
    # so data starts exactly where original expects.
    reserved = data_start - toc2_start
    if reserved < 0:
        raise RuntimeError("data_start < toc2_start (unexpected file layout).")

    if len(new_toc2) > reserved:
        raise RuntimeError(
            f"New TOC2 ({len(new_toc2)} bytes) is larger than reserved header region ({reserved} bytes). "
            f"Shorten paths or reduce entry size; otherwise the format needs a deeper header rewrite."
        )

    # Prefix: everything before toc2_start stays identical
    prefix = data[:toc2_start]
    padding = b"\x00" * (reserved - len(new_toc2))

    out = prefix + new_toc2 + padding + new_data

    with open(out_cff, "wb") as f:
        f.write(out)

    print(f"wrote: {out_cff}")
    print(f"output size: {len(out)} bytes")

if __name__ == "__main__":
    main()